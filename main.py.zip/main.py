import discord
from discord import app_commands
from discord.ext import commands
import random

# Configuração básica
class MyBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True # Necessário para comandos de usuário/membro
        intents.message_content = True
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        await self.tree.sync() # Sincroniza os comandos /
        print(f"Comandos sincronizados para {self.user}")

bot = MyBot()

@bot.event
async def on_ready():
    print(f'Bot logado como {bot.user}')

# --- [ 🛡️ SEÇÃO DE MODERAÇÃO ] ---

@bot.tree.command(name="limpar", description="Limpa mensagens do chat")
@app_commands.checks.has_permissions(manage_messages=True)
async def limpar(interaction: discord.Interaction, quantidade: int):
    await interaction.response.defer(ephemeral=True)
    deleted = await interaction.channel.purge(limit=quantidade)
    await interaction.followup.send(f"🧹 Removi {len(deleted)} mensagens.")

@bot.tree.command(name="kick", description="Expulsa um membro")
@app_commands.checks.has_permissions(kick_members=True)
async def kick(interaction: discord.Interaction, membro: discord.Member, motivo: str = "Não informado"):
    await membro.kick(reason=motivo)
    await interaction.response.send_message(f"🚫 {membro.name} foi expulso. Motivo: {motivo}")

@bot.tree.command(name="slowmode", description="Define o modo lento do canal")
async def slowmode(interaction: discord.Interaction, segundos: int):
    await interaction.channel.edit(slowmode_delay=segundos)
    await interaction.response.send_message(f"⏳ Modo lento definido para {segundos}s.")

# --- [ 🚀 SEÇÃO de UTILIDADE ] ---

@bot.tree.command(name="ping", description="Latência do bot")
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message(f"🏓 Pong! {round(bot.latency * 1000)}ms")

@bot.tree.command(name="userinfo", description="Dados de um usuário")
async def userinfo(interaction: discord.Interaction, membro: discord.Member = None):
    membro = membro or interaction.user
    embed = discord.Embed(title=f"Informações de {membro.name}", color=0x3498db)
    embed.add_field(name="ID", value=membro.id)
    embed.add_field(name="Entrou no Server", value=membro.joined_at.strftime("%d/%m/%Y"))
    embed.set_thumbnail(url=membro.display_avatar.url)
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="avatar", description="Mostra a foto de alguém")
async def avatar(interaction: discord.Interaction, usuario: discord.User = None):
    usuario = usuario or interaction.user
    await interaction.response.send_message(usuario.display_avatar.url)

# --- [ 🎮 SEÇÃO DE DIVERSÃO ] ---

@bot.tree.command(name="dado", description="Joga um dado")
async def dado(interaction: discord.Interaction, lados: int = 6):
    resultado = random.randint(1, lados)
    await interaction.response.send_message(f"🎲 Você tirou: **{resultado}**")

@bot.tree.command(name="moeda", description="Cara ou Coroa")
async def moeda(interaction: discord.Interaction):
    resultado = random.choice(["Cara", "Coroa"])
    await interaction.response.send_message(f"🪙 Deu **{resultado}**!")

@bot.tree.command(name="abraço", description="Abraça alguém")
async def abraco(interaction: discord.Interaction, membro: discord.Member):
    await interaction.response.send_message(f"🫂 {interaction.user.mention} deu um abraço em {membro.mention}!")

@bot.tree.command(name="ppt", description="Pedra, Papel ou Tesoura")
async def ppt(interaction: discord.Interaction, escolha: str):
    opcoes = ["pedra", "papel", "tesoura"]
    bot_escolha = random.choice(opcoes)
    await interaction.response.send_message(f"Você escolheu {escolha} e eu escolhi {bot_escolha}!")

# TOKEN (Coloque o seu aqui)
bot.run("MTQ1ODkwMTE2OTcxODk1NjA4Mg.GlvJjM.Z1lsTwuclVEEHCDEoaipnSfg8c3vcRFRx00vC4")